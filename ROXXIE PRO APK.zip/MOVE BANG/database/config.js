//credit By Limzzzhama 
//no hapus credit ketauan hapus hitam//

module.exports = {
  domain: "http://crazy-private.ikhsan-hosting.biz.id", // Ubah jadi Domain panel Mu !!!
  port: "2000" // Ubah Jadi Port Panel Mu !!!
};